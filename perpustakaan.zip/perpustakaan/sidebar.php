<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
   
        <div class="container">
                <a href="#"><h3>Dasboard</h3></a>
            <ul>
                <li><a href="#">Master Data</a></li>
                    <ul>
                        <li><a href="admin/master_data/data_administrator/index.php">Administrator</a></li>
                        <li><a href="admin/master_data/data_anggota/index.php">Anggota</a></li>
                        <li><a href="admin/penerbit.php">Penerbit</a></li>
                        <li><a href="admin/buku.php">Buku</a></li>
                        <li><a href="admin/kategori.php">Kategori</a></li>
                    </ul>
            </ul>
            <ul>
                <li><a href="#">Katalog Buku</a></li>
                    <ul>
                        <li><a href="#"></a></li>
                        <li><a href="#"></a></li>
                        <li><a href="#">pesan</a></li>
                    </ul>
            </ul>
            <ul>
                <li><a href="#">Laporan Peminjaman</a></li>
                <li><a href="login.php">Keluar</a></li>
            </ul>
        </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>