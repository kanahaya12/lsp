<?php 
include_once("../sidebar.php");
include_once("../database.php");



?>