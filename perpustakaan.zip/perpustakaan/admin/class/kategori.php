<?php 
include_once("../../database.php");


// "k_kategori" = ['k_kategori'];
// "n_kategori" = ['n_kategori'];
?>