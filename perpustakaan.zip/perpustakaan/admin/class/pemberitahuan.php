<?php 
include_once("../../database.php");

// "isi_pemberitahuan" = ['isi_pemberitahuan'];
// "level_user" = ['level_user'];
// "status" = ['status'];

?>