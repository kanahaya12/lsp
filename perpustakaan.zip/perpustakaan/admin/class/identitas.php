<?php 
include_once("../../database.php");


// "nama" = ['nama'];
// "alamat" = ['alamat'];
// "email" = ['email'];
// "n_hp" = ['n_hp'];

?>