<?php 
include_once("../../database.php");

// "n_anggota" = ["n_anggota"];
// "j_buku" = ["j_buku"];
// "tgl_pengembalian" = ["tgl_pengembalian"];
// "kd_dipinjam" = ["kd_dipinjam"];


// $sql =  "UPDATE pengembalian SET n_anggota='$n_anggota', j_buku='$j_buku', tgl_pengembalian='$tgl_pengembalian', kd_pengembalian='$kd_pengembalian'";

//     $sql =  "SELECT * FORM pengembalian";

//     $sql =  "INSERT INTO pengembalian SET VALUES";

//     $sql =  "DELET FORM pengembalian";
?>