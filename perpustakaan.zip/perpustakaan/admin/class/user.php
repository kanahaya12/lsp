<?php 
include_once("../../database.php");

// public function update($id, $data){
//     "nis" = $data["nis"];
//     "fullname" =$data["fullname"];
//     "username"  = $data["username"];
//     "password" = $data["password"];
//     "kelas" = $data["kelas"];
//     "alamat" = $data["alamat"];
//     "foto" = $data["foto"];

//     $sql =  "UPDATE user SET fullname='$fullname', username='$username', password='$password', kelas='$kelas', alamat='$alamat', foto='$foto' WHERE id="$id"";

//     $sql =  "SELECT * FORM user";

//     $sql =  "INSERT INTO user SET VALUES";

//     $sql =  "DELET FORM user";

// }

?>

