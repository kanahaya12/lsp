<?php 
include_once("../../database.php");

// "judul" =  $data ['judul'];
// "kategori" = $data ['kategori'];
// "penerbit" = $data ['penerbit'];
// "pengarang" = $data ['pengarang'];
// "isbn" = $data ['isbn'];

// $sql = "SELECT * FORM ";

?>