<?php 
include_once("../../database.php");


// "k_penerbit" = ['k_penerbit'];
// "n_penerbit" = ['n_penerbit'];
// "verif" = ['verif'];

// $sql =  "UPDATE penerbit SET k_penerbit='$k_penerbit', n_penerbit='$n_penerbit', verif='$verif'";

//     $sql =  "SELECT * FORM penerbit";

//     $sql =  "INSERT INTO penerbit SET VALUES";

//     $sql =  "DELET FORM penerbit";
?>