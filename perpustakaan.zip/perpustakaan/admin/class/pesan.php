<?php 
include_once("../../database.php");

// "penerima" = ["penerima"];
// "pengirim" = ["pengirim"];
// "j_pesan" = ["j_pesan"];
// "isi_pesan" = ["isi_pesan"];

// $sql =  "UPDATE pesan SET penerima='$penerima', pengirim='$pengirim', j_pesan='$j_pesan', isi_pesan='$isi_pesan', alamat='$alamat', foto='$foto' WHERE id="$id"";

//     $sql =  "SELECT * FORM pesan";

//     $sql =  "INSERT INTO pesan SET VALUES";

//     $sql =  "DELET FORM pesan";

?>