<?php 
include_once("../../database.php");


// "n_anggota" = ['n_anggota'];
// "judul_b" = ['judul_buku'];
// "tgl_peminjaman" = ['tgl_peminjaman'];
// "kd_dipinjam" = ['kd_dipinjam'];

?>